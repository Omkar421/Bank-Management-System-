import {
  useCreateTransaction,
  useListAccounts,
  getListTransactionsQueryKey,
  getGetAccountQueryKey,
  getGetDashboardSummaryQueryKey,
} from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useForm, Controller } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useLocation, useSearch } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";
import { ArrowLeft, ArrowDownToLine, ArrowUpFromLine, ArrowRightLeft, Info } from "lucide-react";
import { Link } from "wouter";
import { formatCurrency } from "@/lib/formatters";

const schema = z
  .object({
    accountId: z.coerce.number().min(1, "Source account is required"),
    type: z.enum(["deposit", "withdrawal", "transfer"]),
    amount: z.coerce.number().min(0.01, "Amount must be greater than 0"),
    description: z.string().min(2, "Description / reference is required"),
    toAccountId: z.coerce.number().optional().nullable(),
  })
  .refine(
    (data) => !(data.type === "transfer" && !data.toAccountId),
    { message: "Destination account is required for transfers", path: ["toAccountId"] }
  )
  .refine(
    (data) => !(data.type === "transfer" && data.accountId === data.toAccountId),
    { message: "Cannot transfer to the same account", path: ["toAccountId"] }
  );

type FormValues = z.infer<typeof schema>;

const typeOptions = [
  { value: "deposit", label: "Deposit", desc: "Add funds to account", icon: ArrowDownToLine, color: "border-emerald-400 bg-emerald-50 text-emerald-700" },
  { value: "withdrawal", label: "Withdrawal", desc: "Remove funds from account", icon: ArrowUpFromLine, color: "border-red-400 bg-red-50 text-red-700" },
  { value: "transfer", label: "Transfer", desc: "Move funds between accounts", icon: ArrowRightLeft, color: "border-blue-400 bg-blue-50 text-blue-700" },
];

export default function NewTransaction() {
  const [, setLocation] = useLocation();
  const search = useSearch();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const params = new URLSearchParams(search);
  const initialAccountId = params.get("accountId");

  const { data: accounts, isLoading: loadingAccounts } = useListAccounts();
  const createTransaction = useCreateTransaction();

  const { register, handleSubmit, control, watch, formState: { errors } } = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: {
      accountId: initialAccountId ? Number(initialAccountId) : (undefined as unknown as number),
      type: "deposit",
      amount: undefined as unknown as number,
      description: "",
      toAccountId: null,
    },
  });

  const transactionType = watch("type");
  const selectedAccountId = watch("accountId");
  const activeAccounts = accounts?.filter((a) => a.status === "active") || [];
  const selectedAccount = activeAccounts.find((a) => a.id === Number(selectedAccountId));

  const onSubmit = (data: FormValues) => {
    createTransaction.mutate(
      { data },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getListTransactionsQueryKey() });
          queryClient.invalidateQueries({ queryKey: getGetAccountQueryKey(data.accountId) });
          if (data.toAccountId) {
            queryClient.invalidateQueries({ queryKey: getGetAccountQueryKey(data.toAccountId) });
          }
          queryClient.invalidateQueries({ queryKey: getGetDashboardSummaryQueryKey() });
          toast({
            title: "Transaction completed",
            description: `${data.type.charAt(0).toUpperCase() + data.type.slice(1)} of ${formatCurrency(data.amount)} was processed successfully.`,
          });
          setLocation("/transactions");
        },
        onError: (error: any) => {
          toast({
            title: "Transaction failed",
            description: error?.response?.data?.error || error.message || "An unexpected error occurred.",
            variant: "destructive",
          });
        },
      }
    );
  };

  return (
    <div className="flex flex-col gap-6 max-w-2xl mx-auto w-full">
      <div className="flex items-center gap-3">
        <Link href="/transactions">
          <Button variant="ghost" size="icon">
            <ArrowLeft className="h-4 w-4" />
          </Button>
        </Link>
        <div>
          <h1 className="text-2xl font-bold tracking-tight">New Transaction</h1>
          <p className="text-sm text-muted-foreground">Process a deposit, withdrawal, or transfer.</p>
        </div>
      </div>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base">Transaction Type</CardTitle>
        </CardHeader>
        <CardContent>
          <Controller
            name="type"
            control={control}
            render={({ field }) => (
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {typeOptions.map((opt) => {
                  const Icon = opt.icon;
                  const isSelected = field.value === opt.value;
                  return (
                    <button
                      key={opt.value}
                      type="button"
                      onClick={() => field.onChange(opt.value)}
                      className={`flex flex-col items-start gap-1.5 p-4 rounded-lg border-2 text-left transition-all ${
                        isSelected ? opt.color + " border-2" : "border-border bg-background hover:border-muted-foreground/30"
                      }`}
                    >
                      <Icon className="h-5 w-5" />
                      <span className="font-semibold text-sm">{opt.label}</span>
                      <span className="text-xs opacity-70">{opt.desc}</span>
                    </button>
                  );
                })}
              </div>
            )}
          />
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base">Transaction Details</CardTitle>
          <CardDescription>Fill in the required information below.</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-5">
            <div className="space-y-2">
              <Label>{transactionType === "transfer" ? "Source Account" : "Account"}</Label>
              <Controller
                name="accountId"
                control={control}
                render={({ field }) => (
                  <Select
                    onValueChange={(val) => field.onChange(Number(val))}
                    value={field.value ? String(field.value) : ""}
                    disabled={loadingAccounts}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder={loadingAccounts ? "Loading accounts..." : "Select account"} />
                    </SelectTrigger>
                    <SelectContent>
                      {activeAccounts.map((acc) => (
                        <SelectItem key={acc.id} value={String(acc.id)}>
                          {acc.accountNumber} — {acc.holderName}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                )}
              />
              {selectedAccount && (
                <div className="flex items-center gap-2 text-xs text-muted-foreground bg-muted/40 rounded-md px-3 py-2">
                  <Info className="h-3.5 w-3.5 shrink-0" />
                  Available balance: <span className="font-semibold text-foreground">{formatCurrency(selectedAccount.balance)}</span>
                </div>
              )}
              {errors.accountId && <p className="text-xs text-destructive">{errors.accountId.message}</p>}
            </div>

            {transactionType === "transfer" && (
              <div className="space-y-2">
                <Label>Destination Account</Label>
                <Controller
                  name="toAccountId"
                  control={control}
                  render={({ field }) => (
                    <Select
                      onValueChange={(val) => field.onChange(Number(val))}
                      value={field.value ? String(field.value) : ""}
                      disabled={loadingAccounts}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select destination account" />
                      </SelectTrigger>
                      <SelectContent>
                        {activeAccounts
                          .filter((acc) => acc.id !== Number(selectedAccountId))
                          .map((acc) => (
                            <SelectItem key={acc.id} value={String(acc.id)}>
                              {acc.accountNumber} — {acc.holderName}
                            </SelectItem>
                          ))}
                      </SelectContent>
                    </Select>
                  )}
                />
                {errors.toAccountId && <p className="text-xs text-destructive">{errors.toAccountId.message}</p>}
              </div>
            )}

            <div className="space-y-2">
              <Label htmlFor="amount">Amount (₹)</Label>
              <Input
                id="amount"
                type="number"
                step="0.01"
                min="0.01"
                placeholder="Enter amount"
                {...register("amount")}
              />
              {errors.amount && <p className="text-xs text-destructive">{errors.amount.message}</p>}
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Description / Reference</Label>
              <Input
                id="description"
                placeholder="e.g. Monthly salary, Rent payment, ATM withdrawal"
                {...register("description")}
              />
              {errors.description && <p className="text-xs text-destructive">{errors.description.message}</p>}
            </div>

            <div className="flex flex-col sm:flex-row justify-end gap-3 pt-2 border-t">
              <Link href="/transactions" className="w-full sm:w-auto">
                <Button type="button" variant="outline" className="w-full">Cancel</Button>
              </Link>
              <Button type="submit" disabled={createTransaction.isPending} className="w-full sm:w-auto">
                {createTransaction.isPending ? "Processing..." : "Confirm Transaction"}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
