import { useListTransactions } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { formatCurrency, formatDate } from "@/lib/formatters";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { Skeleton } from "@/components/ui/skeleton";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useState } from "react";
import { Plus, ArrowDownToLine, ArrowUpFromLine, ArrowRightLeft } from "lucide-react";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

type TxnType = "deposit" | "withdrawal" | "transfer" | "all";

const typeConfig: Record<string, { label: string; color: string; icon: React.ElementType; amountColor: string; prefix: string }> = {
  deposit: { label: "Deposit", color: "bg-emerald-100 text-emerald-700 border-emerald-200", icon: ArrowDownToLine, amountColor: "text-emerald-600", prefix: "+" },
  withdrawal: { label: "Withdrawal", color: "bg-red-100 text-red-700 border-red-200", icon: ArrowUpFromLine, amountColor: "text-red-600", prefix: "-" },
  transfer: { label: "Transfer", color: "bg-blue-100 text-blue-700 border-blue-200", icon: ArrowRightLeft, amountColor: "text-blue-600", prefix: "-" },
};

export default function Transactions() {
  const [type, setType] = useState<TxnType>("all");

  const { data: transactions, isLoading } = useListTransactions({
    type: type !== "all" ? type : undefined,
  });

  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Transactions</h1>
          <p className="text-sm text-muted-foreground mt-0.5">
            {transactions ? `${transactions.length} record${transactions.length !== 1 ? "s" : ""}` : "Loading..."}
          </p>
        </div>
        <Link href="/transactions/new">
          <Button className="gap-2">
            <Plus className="h-4 w-4" /> New Transaction
          </Button>
        </Link>
      </div>

      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center gap-3 flex-wrap">
            <span className="text-sm font-medium text-muted-foreground">Filter:</span>
            <div className="flex flex-wrap gap-2">
              {(["all", "deposit", "withdrawal", "transfer"] as TxnType[]).map((t) => (
                <button
                  key={t}
                  onClick={() => setType(t)}
                  className={`text-xs font-semibold px-3 py-1.5 rounded-full border transition-all capitalize ${
                    type === t
                      ? "bg-primary text-primary-foreground border-primary"
                      : "bg-background text-muted-foreground border-border hover:border-primary/50"
                  }`}
                >
                  {t === "all" ? "All Types" : t}
                </button>
              ))}
            </div>
          </div>
        </CardHeader>
        <CardContent className="px-0 pb-0">
          {isLoading ? (
            <div className="space-y-2 px-6 pb-6">
              {[...Array(5)].map((_, i) => <Skeleton key={i} className="h-12 w-full" />)}
            </div>
          ) : (
            <>
              {/* Desktop table */}
              <div className="hidden md:block overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-muted/30">
                      <TableHead className="font-semibold">Date & Time</TableHead>
                      <TableHead className="font-semibold">Account</TableHead>
                      <TableHead className="font-semibold">Customer</TableHead>
                      <TableHead className="font-semibold">Type</TableHead>
                      <TableHead className="font-semibold">Description</TableHead>
                      <TableHead className="text-right font-semibold">Amount</TableHead>
                      <TableHead className="text-right font-semibold">Balance After</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {transactions?.map((txn) => {
                      const cfg = typeConfig[txn.type];
                      const Icon = cfg?.icon;
                      return (
                        <TableRow key={txn.id} className="hover:bg-muted/20">
                          <TableCell className="text-sm whitespace-nowrap">{formatDate(txn.createdAt)}</TableCell>
                          <TableCell>
                            <Link href={`/accounts/${txn.accountId}`} className="font-mono text-sm font-medium text-primary hover:underline">
                              {txn.accountNumber}
                            </Link>
                          </TableCell>
                          <TableCell className="text-sm">{txn.holderName}</TableCell>
                          <TableCell>
                            <span className={`inline-flex items-center gap-1 text-xs font-semibold px-2 py-0.5 rounded-full border capitalize ${cfg?.color}`}>
                              {Icon && <Icon className="h-3 w-3" />}
                              {cfg?.label ?? txn.type}
                            </span>
                          </TableCell>
                          <TableCell className="text-sm text-muted-foreground max-w-[200px] truncate" title={txn.description}>
                            {txn.description}
                          </TableCell>
                          <TableCell className={`text-right font-semibold text-sm ${cfg?.amountColor}`}>
                            {cfg?.prefix}{formatCurrency(txn.amount)}
                          </TableCell>
                          <TableCell className="text-right text-sm text-muted-foreground">
                            {formatCurrency(txn.balanceAfter)}
                          </TableCell>
                        </TableRow>
                      );
                    })}
                    {!transactions?.length && (
                      <TableRow>
                        <TableCell colSpan={7} className="h-32 text-center text-muted-foreground">
                          {type !== "all" ? `No ${type} transactions found.` : "No transactions found."}
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </div>

              {/* Mobile card list */}
              <div className="md:hidden divide-y">
                {transactions?.map((txn) => {
                  const cfg = typeConfig[txn.type];
                  const Icon = cfg?.icon;
                  return (
                    <div key={txn.id} className="flex items-center gap-3 px-4 py-3">
                      <div className={`p-2 rounded-full ${cfg?.color}`}>
                        {Icon && <Icon className="h-4 w-4" />}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between gap-2">
                          <p className="text-sm font-medium truncate">{txn.description}</p>
                          <p className={`text-sm font-bold shrink-0 ${cfg?.amountColor}`}>
                            {cfg?.prefix}{formatCurrency(txn.amount)}
                          </p>
                        </div>
                        <div className="flex items-center gap-2 mt-0.5">
                          <Link href={`/accounts/${txn.accountId}`} className="text-xs text-primary font-mono hover:underline">
                            {txn.accountNumber}
                          </Link>
                          <span className="text-xs text-muted-foreground">•</span>
                          <span className="text-xs text-muted-foreground">{txn.holderName}</span>
                        </div>
                        <p className="text-xs text-muted-foreground mt-0.5">{formatDate(txn.createdAt)}</p>
                      </div>
                    </div>
                  );
                })}
                {!transactions?.length && (
                  <div className="py-12 text-center text-muted-foreground text-sm px-4">
                    {type !== "all" ? `No ${type} transactions found.` : "No transactions found."}
                  </div>
                )}
              </div>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
