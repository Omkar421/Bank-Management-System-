import { useGetDashboardSummary, useGetRecentTransactions } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { formatCurrency, formatDate } from "@/lib/formatters";
import {
  Building2,
  ArrowDownToLine,
  ArrowUpFromLine,
  Wallet,
  ArrowRightLeft,
  Users,
  TrendingUp,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { Skeleton } from "@/components/ui/skeleton";

const txnTypeConfig: Record<string, { color: string; icon: React.ElementType; amountColor: string; prefix: string }> = {
  deposit:    { color: "bg-emerald-100 text-emerald-700", icon: ArrowDownToLine,  amountColor: "text-emerald-600", prefix: "+" },
  withdrawal: { color: "bg-red-100 text-red-700",         icon: ArrowUpFromLine,  amountColor: "text-red-600",     prefix: "-" },
  transfer:   { color: "bg-blue-100 text-blue-700",       icon: ArrowRightLeft,   amountColor: "text-blue-600",    prefix: "-" },
};

export default function Dashboard() {
  const { data: summary, isLoading: loadingSummary } = useGetDashboardSummary();
  const { data: recentTransactions, isLoading: loadingTransactions } = useGetRecentTransactions();

  const summaryCards = [
    {
      label: "Total Portfolio",
      value: formatCurrency(summary?.totalBalance ?? 0),
      icon: Wallet,
      sub: `Across ${summary?.totalAccounts ?? 0} accounts`,
      color: "text-primary",
    },
    {
      label: "Active Accounts",
      value: String(summary?.activeAccounts ?? 0),
      icon: Users,
      sub: `${(summary?.totalAccounts ?? 0) - (summary?.activeAccounts ?? 0)} inactive`,
      color: "text-emerald-600",
    },
    {
      label: "Total Deposits",
      value: formatCurrency(summary?.totalDeposits ?? 0),
      icon: ArrowDownToLine,
      sub: "All time",
      color: "text-emerald-600",
    },
    {
      label: "Total Withdrawals",
      value: formatCurrency(summary?.totalWithdrawals ?? 0),
      icon: ArrowUpFromLine,
      sub: "All time",
      color: "text-red-500",
    },
  ];

  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Dashboard</h1>
          <p className="text-sm text-muted-foreground">Welcome to NationalTrust Bank Management System.</p>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <Link href="/transactions/new">
            <Button size="sm">New Transaction</Button>
          </Link>
          <Link href="/accounts/new">
            <Button variant="outline" size="sm">Open Account</Button>
          </Link>
        </div>
      </div>

      <div className="grid gap-4 grid-cols-2 lg:grid-cols-4">
        {summaryCards.map((card) => {
          const Icon = card.icon;
          return (
            <Card key={card.label}>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 pt-4 px-4">
                <CardTitle className="text-xs font-medium text-muted-foreground uppercase tracking-wider">{card.label}</CardTitle>
                <Icon className={`h-4 w-4 ${card.color}`} />
              </CardHeader>
              <CardContent className="px-4 pb-4">
                {loadingSummary ? (
                  <Skeleton className="h-7 w-24" />
                ) : (
                  <>
                    <div className={`text-xl sm:text-2xl font-bold ${card.color}`}>{card.value}</div>
                    <p className="text-xs text-muted-foreground mt-1">{card.sub}</p>
                  </>
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader className="flex flex-row items-center justify-between pb-3">
            <div>
              <CardTitle className="text-base">Recent Transactions</CardTitle>
              <p className="text-xs text-muted-foreground mt-0.5">
                {loadingSummary ? "—" : `${summary?.transactionsToday ?? 0} transaction${summary?.transactionsToday !== 1 ? "s" : ""} today`}
              </p>
            </div>
            <Link href="/transactions">
              <Button variant="ghost" size="sm" className="gap-1.5 text-xs">
                View All <ArrowRightLeft className="h-3.5 w-3.5" />
              </Button>
            </Link>
          </CardHeader>
          <CardContent className="px-0 pb-0">
            {loadingTransactions ? (
              <div className="space-y-1 px-6 pb-4">
                {[...Array(4)].map((_, i) => <Skeleton key={i} className="h-14 w-full" />)}
              </div>
            ) : (
              <div className="divide-y">
                {recentTransactions?.slice(0, 7).map((txn) => {
                  const cfg = txnTypeConfig[txn.type];
                  const Icon = cfg?.icon;
                  return (
                    <div key={txn.id} className="flex items-center gap-3 px-4 sm:px-6 py-3">
                      <div className={`p-2 rounded-full shrink-0 ${cfg?.color}`}>
                        {Icon && <Icon className="h-3.5 w-3.5" />}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium truncate">{txn.description}</p>
                        <div className="flex items-center gap-1.5 mt-0.5 flex-wrap">
                          <Link href={`/accounts/${txn.accountId}`} className="text-xs text-primary font-mono hover:underline">
                            {txn.accountNumber}
                          </Link>
                          <span className="text-xs text-muted-foreground hidden sm:inline">•</span>
                          <span className="text-xs text-muted-foreground hidden sm:inline">{txn.holderName}</span>
                          <span className="text-xs text-muted-foreground">•</span>
                          <span className="text-xs text-muted-foreground">{formatDate(txn.createdAt)}</span>
                        </div>
                      </div>
                      <p className={`text-sm font-bold shrink-0 ${cfg?.amountColor}`}>
                        {cfg?.prefix}{formatCurrency(txn.amount)}
                      </p>
                    </div>
                  );
                })}
                {!recentTransactions?.length && (
                  <div className="py-12 text-center text-muted-foreground text-sm">
                    No transactions yet.
                  </div>
                )}
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <TrendingUp className="h-4 w-4 text-primary" /> Quick Actions
            </CardTitle>
          </CardHeader>
          <CardContent className="flex flex-col gap-3">
            <Link href="/accounts/new" className="block">
              <div className="flex items-center gap-3 p-3 rounded-lg border hover:bg-muted/40 transition-colors cursor-pointer">
                <div className="p-2 rounded-full bg-primary/10">
                  <Users className="h-4 w-4 text-primary" />
                </div>
                <div>
                  <p className="text-sm font-medium">Open New Account</p>
                  <p className="text-xs text-muted-foreground">Register a new customer</p>
                </div>
              </div>
            </Link>
            <Link href="/transactions/new" className="block">
              <div className="flex items-center gap-3 p-3 rounded-lg border hover:bg-muted/40 transition-colors cursor-pointer">
                <div className="p-2 rounded-full bg-emerald-100">
                  <ArrowDownToLine className="h-4 w-4 text-emerald-600" />
                </div>
                <div>
                  <p className="text-sm font-medium">Make a Deposit</p>
                  <p className="text-xs text-muted-foreground">Add funds to an account</p>
                </div>
              </div>
            </Link>
            <Link href="/transactions/new" className="block">
              <div className="flex items-center gap-3 p-3 rounded-lg border hover:bg-muted/40 transition-colors cursor-pointer">
                <div className="p-2 rounded-full bg-red-100">
                  <ArrowUpFromLine className="h-4 w-4 text-red-600" />
                </div>
                <div>
                  <p className="text-sm font-medium">Process Withdrawal</p>
                  <p className="text-xs text-muted-foreground">Remove funds from account</p>
                </div>
              </div>
            </Link>
            <Link href="/transactions/new" className="block">
              <div className="flex items-center gap-3 p-3 rounded-lg border hover:bg-muted/40 transition-colors cursor-pointer">
                <div className="p-2 rounded-full bg-blue-100">
                  <ArrowRightLeft className="h-4 w-4 text-blue-600" />
                </div>
                <div>
                  <p className="text-sm font-medium">Transfer Funds</p>
                  <p className="text-xs text-muted-foreground">Move money between accounts</p>
                </div>
              </div>
            </Link>
            <div className="mt-2 pt-3 border-t">
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <Building2 className="h-3.5 w-3.5" />
                <span>NationalTrust Bank — Est. 2024</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
