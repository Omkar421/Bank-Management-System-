import { useGetAccount, useListTransactions, getGetAccountQueryKey, useUpdateAccount, useDeleteAccount, getListAccountsQueryKey } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { formatCurrency, formatDate } from "@/lib/formatters";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Link, useParams, useLocation } from "wouter";
import { Skeleton } from "@/components/ui/skeleton";
import { ArrowLeft, Trash2, ShieldAlert, MapPin, Phone, Mail, User, CreditCard, Calendar, Edit2, X, Check } from "lucide-react";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useState } from "react";

function InfoRow({ icon: Icon, label, value }: { icon: React.ElementType; label: string; value: string }) {
  return (
    <div className="flex items-start gap-3 py-3 border-b last:border-0">
      <div className="mt-0.5 p-1.5 rounded-md bg-muted">
        <Icon className="h-3.5 w-3.5 text-muted-foreground" />
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider">{label}</p>
        <p className="font-medium text-sm mt-0.5 break-words">{value}</p>
      </div>
    </div>
  );
}

export default function AccountDetail() {
  const { id } = useParams();
  const accountId = Number(id);
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: account, isLoading: loadingAccount } = useGetAccount(accountId, {
    query: { enabled: !!accountId, queryKey: getGetAccountQueryKey(accountId) }
  });

  const { data: transactions, isLoading: loadingTransactions } = useListTransactions({ accountId });

  const updateAccount = useUpdateAccount();
  const deleteAccount = useDeleteAccount();

  const [isEditingStatus, setIsEditingStatus] = useState(false);
  const [isEditingDetails, setIsEditingDetails] = useState(false);
  const [editForm, setEditForm] = useState({ holderName: "", email: "", phone: "", address: "" });

  const statusColors: Record<string, string> = {
    active: "bg-emerald-100 text-emerald-700 border-emerald-200",
    inactive: "bg-yellow-100 text-yellow-700 border-yellow-200",
    closed: "bg-red-100 text-red-700 border-red-200",
  };

  const typeColors: Record<string, string> = {
    savings: "bg-blue-100 text-blue-700 border-blue-200",
    checking: "bg-purple-100 text-purple-700 border-purple-200",
    current: "bg-orange-100 text-orange-700 border-orange-200",
  };

  const handleStatusChange = (newStatus: "active" | "inactive" | "closed") => {
    if (!account) return;
    updateAccount.mutate(
      { id: accountId, data: { status: newStatus } },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getGetAccountQueryKey(accountId) });
          queryClient.invalidateQueries({ queryKey: getListAccountsQueryKey() });
          toast({ title: "Account status updated successfully" });
          setIsEditingStatus(false);
        },
        onError: (err: any) => {
          toast({ title: "Failed to update status", description: err?.response?.data?.error || err.message, variant: "destructive" });
        }
      }
    );
  };

  const startEditDetails = () => {
    if (!account) return;
    setEditForm({ holderName: account.holderName, email: account.email, phone: account.phone, address: account.address });
    setIsEditingDetails(true);
  };

  const saveEditDetails = () => {
    updateAccount.mutate(
      { id: accountId, data: editForm },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getGetAccountQueryKey(accountId) });
          queryClient.invalidateQueries({ queryKey: getListAccountsQueryKey() });
          toast({ title: "Customer details updated successfully" });
          setIsEditingDetails(false);
        },
        onError: (err: any) => {
          toast({ title: "Failed to update details", description: err?.response?.data?.error || err.message, variant: "destructive" });
        }
      }
    );
  };

  const handleDelete = () => {
    deleteAccount.mutate(
      { id: accountId },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getListAccountsQueryKey() });
          toast({ title: "Account closed and deleted" });
          setLocation("/accounts");
        },
        onError: (err: any) => {
          toast({ title: "Failed to delete account", description: err?.response?.data?.error || err.message, variant: "destructive" });
        }
      }
    );
  };

  if (loadingAccount) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-10 w-64" />
        <div className="grid gap-6 md:grid-cols-3">
          <Skeleton className="h-64 md:col-span-2" />
          <Skeleton className="h-64" />
        </div>
      </div>
    );
  }

  if (!account) {
    return (
      <div className="flex flex-col items-center justify-center py-16 gap-4">
        <p className="text-muted-foreground">Account not found.</p>
        <Link href="/accounts"><Button variant="outline">Back to Accounts</Button></Link>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div className="flex items-center gap-3">
          <Link href="/accounts">
            <Button variant="ghost" size="icon">
              <ArrowLeft className="h-4 w-4" />
            </Button>
          </Link>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h1 className="text-xl font-bold tracking-tight">{account.holderName}</h1>
              <span className={`text-xs font-semibold px-2 py-0.5 rounded-full border capitalize ${statusColors[account.status] ?? ""}`}>
                {account.status}
              </span>
              <span className={`text-xs font-semibold px-2 py-0.5 rounded-full border capitalize ${typeColors[account.accountType] ?? ""}`}>
                {account.accountType}
              </span>
            </div>
            <p className="text-sm text-muted-foreground font-mono">{account.accountNumber}</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Link href={`/transactions/new?accountId=${account.id}`}>
            <Button>New Transaction</Button>
          </Link>
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button variant="outline" size="icon" className="text-destructive border-destructive/30 hover:bg-destructive/10">
                <Trash2 className="h-4 w-4" />
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Close and Delete Account?</AlertDialogTitle>
                <AlertDialogDescription>
                  This will permanently close account <strong>{account.accountNumber}</strong> for <strong>{account.holderName}</strong> and delete all associated records. This action cannot be undone.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground">Delete Account</AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2 flex flex-col gap-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-3">
              <CardTitle className="text-base">Customer Details</CardTitle>
              {!isEditingDetails ? (
                <Button variant="outline" size="sm" className="gap-1.5" onClick={startEditDetails}>
                  <Edit2 className="h-3.5 w-3.5" /> Edit
                </Button>
              ) : (
                <div className="flex gap-2">
                  <Button size="sm" variant="ghost" onClick={() => setIsEditingDetails(false)}>
                    <X className="h-3.5 w-3.5" />
                  </Button>
                  <Button size="sm" onClick={saveEditDetails} disabled={updateAccount.isPending}>
                    <Check className="h-3.5 w-3.5 mr-1" /> Save
                  </Button>
                </div>
              )}
            </CardHeader>
            <CardContent>
              {isEditingDetails ? (
                <div className="space-y-4">
                  <div className="grid gap-4 sm:grid-cols-2">
                    <div className="space-y-1.5">
                      <label className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Full Name</label>
                      <Input value={editForm.holderName} onChange={e => setEditForm(f => ({ ...f, holderName: e.target.value }))} />
                    </div>
                    <div className="space-y-1.5">
                      <label className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Phone Number</label>
                      <Input value={editForm.phone} onChange={e => setEditForm(f => ({ ...f, phone: e.target.value }))} />
                    </div>
                    <div className="space-y-1.5 sm:col-span-2">
                      <label className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Email Address</label>
                      <Input type="email" value={editForm.email} onChange={e => setEditForm(f => ({ ...f, email: e.target.value }))} />
                    </div>
                    <div className="space-y-1.5 sm:col-span-2">
                      <label className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Home Address</label>
                      <Textarea rows={3} value={editForm.address} onChange={e => setEditForm(f => ({ ...f, address: e.target.value }))} />
                    </div>
                  </div>
                </div>
              ) : (
                <div className="divide-y">
                  <InfoRow icon={User} label="Full Name" value={account.holderName} />
                  <InfoRow icon={Phone} label="Phone Number" value={account.phone} />
                  <InfoRow icon={Mail} label="Email Address" value={account.email} />
                  <InfoRow icon={MapPin} label="Home Address" value={account.address || "Not provided"} />
                  <InfoRow icon={Calendar} label="Account Opened" value={formatDate(account.createdAt)} />
                  <InfoRow icon={CreditCard} label="Account Number" value={account.accountNumber} />
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base">Account Status</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-4">
                {!isEditingStatus ? (
                  <>
                    <span className={`inline-flex items-center gap-1.5 text-sm font-semibold px-3 py-1 rounded-full border capitalize ${statusColors[account.status] ?? ""}`}>
                      {account.status}
                    </span>
                    <Button variant="outline" size="sm" onClick={() => setIsEditingStatus(true)}>Change Status</Button>
                  </>
                ) : (
                  <div className="flex items-center gap-3">
                    <Select defaultValue={account.status} onValueChange={(v) => handleStatusChange(v as "active" | "inactive" | "closed")} disabled={updateAccount.isPending}>
                      <SelectTrigger className="w-[180px]">
                        <SelectValue placeholder="Status" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="active">Active</SelectItem>
                        <SelectItem value="inactive">Inactive</SelectItem>
                        <SelectItem value="closed">Closed</SelectItem>
                      </SelectContent>
                    </Select>
                    <Button variant="ghost" size="sm" onClick={() => setIsEditingStatus(false)}>Cancel</Button>
                  </div>
                )}
                {account.status === 'closed' && (
                  <span className="text-sm text-destructive flex items-center gap-1">
                    <ShieldAlert className="h-4 w-4" /> Closed — no new transactions allowed.
                  </span>
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="flex flex-col gap-6">
          <Card className="bg-primary text-primary-foreground">
            <CardHeader className="pb-2">
              <CardTitle className="text-primary-foreground/70 text-xs font-medium uppercase tracking-wider">Current Balance</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-4xl font-bold">{formatCurrency(account.balance)}</div>
              <div className="mt-4 pt-4 border-t border-primary-foreground/20">
                <p className="text-xs text-primary-foreground/70 uppercase tracking-wider">Account Type</p>
                <p className="font-semibold capitalize mt-0.5">{account.accountType} Account</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Transaction History</CardTitle>
          <CardDescription>All recorded transactions for account {account.accountNumber}</CardDescription>
        </CardHeader>
        <CardContent>
          {loadingTransactions ? (
            <div className="space-y-2">
              <Skeleton className="h-10 w-full" />
              <Skeleton className="h-10 w-full" />
              <Skeleton className="h-10 w-full" />
            </div>
          ) : (
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Date</TableHead>
                    <TableHead>Description</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead className="text-right">Amount</TableHead>
                    <TableHead className="text-right">Balance After</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {transactions?.map((transaction) => (
                    <TableRow key={transaction.id}>
                      <TableCell className="whitespace-nowrap text-sm">{formatDate(transaction.createdAt)}</TableCell>
                      <TableCell className="text-sm">{transaction.description}</TableCell>
                      <TableCell>
                        <span className={`text-xs font-semibold px-2 py-0.5 rounded-full border capitalize ${
                          transaction.type === 'deposit' ? 'bg-emerald-100 text-emerald-700 border-emerald-200' :
                          transaction.type === 'withdrawal' ? 'bg-red-100 text-red-700 border-red-200' :
                          'bg-blue-100 text-blue-700 border-blue-200'
                        }`}>{transaction.type}</span>
                      </TableCell>
                      <TableCell className={`text-right font-semibold text-sm ${
                        transaction.type === 'deposit' ? 'text-emerald-600' : 'text-red-600'
                      }`}>
                        {transaction.type === 'deposit' ? '+' : '-'}{formatCurrency(transaction.amount)}
                      </TableCell>
                      <TableCell className="text-right text-muted-foreground text-sm">
                        {formatCurrency(transaction.balanceAfter)}
                      </TableCell>
                    </TableRow>
                  ))}
                  {!transactions?.length && (
                    <TableRow>
                      <TableCell colSpan={5} className="h-24 text-center text-muted-foreground">
                        No transactions found for this account.
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
