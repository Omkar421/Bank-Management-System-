import { useListAccounts } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { formatCurrency, formatDate } from "@/lib/formatters";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { Skeleton } from "@/components/ui/skeleton";
import { Input } from "@/components/ui/input";
import { useState } from "react";
import { Search, Plus, MapPin } from "lucide-react";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

const statusColors: Record<string, string> = {
  active: "bg-emerald-100 text-emerald-700 border-emerald-200",
  inactive: "bg-yellow-100 text-yellow-700 border-yellow-200",
  closed: "bg-red-100 text-red-700 border-red-200",
};

const typeColors: Record<string, string> = {
  savings: "bg-blue-100 text-blue-700 border-blue-200",
  checking: "bg-purple-100 text-purple-700 border-purple-200",
  current: "bg-orange-100 text-orange-700 border-orange-200",
};

export default function Accounts() {
  const [search, setSearch] = useState("");
  const { data: accounts, isLoading } = useListAccounts({ search: search || undefined });

  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Customer Accounts</h1>
          <p className="text-sm text-muted-foreground mt-0.5">
            {accounts ? `${accounts.length} account${accounts.length !== 1 ? "s" : ""} found` : "Loading..."}
          </p>
        </div>
        <Link href="/accounts/new">
          <Button className="gap-2">
            <Plus className="h-4 w-4" /> Open Account
          </Button>
        </Link>
      </div>

      <Card>
        <CardHeader className="pb-3">
          <div className="relative max-w-sm">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Search by name, account number, or email..."
              className="pl-8"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
        </CardHeader>
        <CardContent className="px-0 pb-0">
          {isLoading ? (
            <div className="space-y-2 px-6 pb-6">
              {[...Array(4)].map((_, i) => <Skeleton key={i} className="h-12 w-full" />)}
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="bg-muted/30">
                    <TableHead className="font-semibold">Account No.</TableHead>
                    <TableHead className="font-semibold">Customer Name</TableHead>
                    <TableHead className="font-semibold hidden md:table-cell">Contact</TableHead>
                    <TableHead className="font-semibold hidden lg:table-cell">Address</TableHead>
                    <TableHead className="font-semibold">Type</TableHead>
                    <TableHead className="font-semibold">Status</TableHead>
                    <TableHead className="text-right font-semibold">Balance</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {accounts?.map((account) => (
                    <TableRow key={account.id} className="hover:bg-muted/20">
                      <TableCell className="font-mono text-sm">
                        <Link href={`/accounts/${account.id}`} className="hover:underline text-primary font-medium">
                          {account.accountNumber}
                        </Link>
                        <div className="text-xs text-muted-foreground">{formatDate(account.createdAt)}</div>
                      </TableCell>
                      <TableCell>
                        <div className="font-medium">{account.holderName}</div>
                      </TableCell>
                      <TableCell className="hidden md:table-cell">
                        <div className="text-sm">{account.email}</div>
                        <div className="text-xs text-muted-foreground">{account.phone}</div>
                      </TableCell>
                      <TableCell className="hidden lg:table-cell">
                        <div className="flex items-start gap-1 text-sm text-muted-foreground max-w-[200px]">
                          {account.address ? (
                            <>
                              <MapPin className="h-3.5 w-3.5 mt-0.5 shrink-0" />
                              <span className="truncate">{account.address}</span>
                            </>
                          ) : (
                            <span className="italic">Not provided</span>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <span className={`text-xs font-semibold px-2 py-0.5 rounded-full border capitalize ${typeColors[account.accountType] ?? ""}`}>
                          {account.accountType}
                        </span>
                      </TableCell>
                      <TableCell>
                        <span className={`text-xs font-semibold px-2 py-0.5 rounded-full border capitalize ${statusColors[account.status] ?? ""}`}>
                          {account.status}
                        </span>
                      </TableCell>
                      <TableCell className="text-right font-bold">
                        {formatCurrency(account.balance)}
                      </TableCell>
                    </TableRow>
                  ))}
                  {!accounts?.length && (
                    <TableRow>
                      <TableCell colSpan={7} className="h-24 text-center text-muted-foreground">
                        {search ? `No accounts matching "${search}"` : "No accounts found."}
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
