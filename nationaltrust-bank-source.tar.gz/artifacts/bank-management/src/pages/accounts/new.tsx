import { useCreateAccount, getListAccountsQueryKey, getGetDashboardSummaryQueryKey } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useForm, Controller } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";
import { ArrowLeft, UserPlus, Building2 } from "lucide-react";
import { Link } from "wouter";

const schema = z.object({
  holderName: z.string().min(2, "Full name is required"),
  email: z.string().email("Invalid email address"),
  phone: z.string().min(7, "Phone number is required"),
  address: z.string().min(5, "Address is required"),
  accountType: z.enum(["savings", "checking", "current"]),
  initialDeposit: z.coerce.number().min(0, "Initial deposit cannot be negative"),
});

type FormValues = z.infer<typeof schema>;

export default function NewAccount() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const createAccount = useCreateAccount();

  const { register, handleSubmit, control, formState: { errors } } = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: {
      holderName: "",
      email: "",
      phone: "",
      address: "",
      accountType: "savings",
      initialDeposit: 0,
    }
  });

  const onSubmit = (data: FormValues) => {
    createAccount.mutate(
      { data },
      {
        onSuccess: (account) => {
          queryClient.invalidateQueries({ queryKey: getListAccountsQueryKey() });
          queryClient.invalidateQueries({ queryKey: getGetDashboardSummaryQueryKey() });
          toast({
            title: "Account opened successfully",
            description: `Account ${account.accountNumber} has been created for ${account.holderName}.`,
          });
          setLocation(`/accounts/${account.id}`);
        },
        onError: (error: any) => {
          toast({
            title: "Failed to open account",
            description: error?.response?.data?.error || error.message || "An unexpected error occurred.",
            variant: "destructive",
          });
        }
      }
    );
  };

  return (
    <div className="flex flex-col gap-6 max-w-3xl mx-auto w-full">
      <div className="flex items-center gap-4">
        <Link href="/accounts">
          <Button variant="ghost" size="icon">
            <ArrowLeft className="h-4 w-4" />
          </Button>
        </Link>
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Open New Account</h1>
          <p className="text-sm text-muted-foreground">Fill in the customer details to open a new bank account.</p>
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <UserPlus className="h-5 w-5 text-primary" />
                Customer Information
              </CardTitle>
              <CardDescription>Enter the customer's personal and contact details.</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit(onSubmit)} className="space-y-5" id="new-account-form">
                <div className="space-y-2">
                  <Label htmlFor="holderName">Full Name <span className="text-destructive">*</span></Label>
                  <Input id="holderName" {...register("holderName")} placeholder="e.g. John Michael Doe" />
                  {errors.holderName && <p className="text-xs text-destructive">{errors.holderName.message}</p>}
                </div>

                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="email">Email Address <span className="text-destructive">*</span></Label>
                    <Input id="email" type="email" {...register("email")} placeholder="john@example.com" />
                    {errors.email && <p className="text-xs text-destructive">{errors.email.message}</p>}
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="phone">Phone Number <span className="text-destructive">*</span></Label>
                    <Input id="phone" type="tel" {...register("phone")} placeholder="(555) 123-4567" />
                    {errors.phone && <p className="text-xs text-destructive">{errors.phone.message}</p>}
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="address">Home Address <span className="text-destructive">*</span></Label>
                  <Textarea
                    id="address"
                    {...register("address")}
                    placeholder="Street, City, State, ZIP Code"
                    rows={3}
                  />
                  {errors.address && <p className="text-xs text-destructive">{errors.address.message}</p>}
                </div>

                <div className="border-t pt-5 grid gap-4 sm:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="accountType">Account Type <span className="text-destructive">*</span></Label>
                    <Controller
                      name="accountType"
                      control={control}
                      render={({ field }) => (
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <SelectTrigger>
                            <SelectValue placeholder="Select type" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="savings">Savings Account</SelectItem>
                            <SelectItem value="checking">Checking Account</SelectItem>
                            <SelectItem value="current">Current Account</SelectItem>
                          </SelectContent>
                        </Select>
                      )}
                    />
                    {errors.accountType && <p className="text-xs text-destructive">{errors.accountType.message}</p>}
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="initialDeposit">Initial Deposit ($) <span className="text-destructive">*</span></Label>
                    <Input id="initialDeposit" type="number" step="0.01" min="0" {...register("initialDeposit")} />
                    {errors.initialDeposit && <p className="text-xs text-destructive">{errors.initialDeposit.message}</p>}
                  </div>
                </div>
              </form>
            </CardContent>
          </Card>
        </div>

        <div className="flex flex-col gap-4">
          <Card className="bg-primary text-primary-foreground">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium opacity-80 flex items-center gap-2">
                <Building2 className="h-4 w-4" /> NationalTrust Bank
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-xs opacity-70 leading-relaxed">
                All accounts are FDIC insured up to $250,000. A unique account number will be automatically assigned upon opening.
              </p>
            </CardContent>
          </Card>

          <div className="flex flex-col gap-2">
            <Button type="submit" form="new-account-form" disabled={createAccount.isPending} className="w-full">
              {createAccount.isPending ? "Opening Account..." : "Open Account"}
            </Button>
            <Link href="/accounts">
              <Button type="button" variant="outline" className="w-full">Cancel</Button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
