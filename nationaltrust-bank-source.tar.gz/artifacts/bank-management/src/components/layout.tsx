import { useLocation } from "wouter";
import { Link } from "wouter";
import { 
  Building2, 
  LayoutDashboard, 
  Users, 
  ArrowRightLeft, 
  Menu,
  ShieldCheck
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { useState } from "react";

const BANK_NAME = "NationalTrust Bank";
const BANK_TAGLINE = "Trusted. Secure. Reliable.";

function NavLinks({ onNavigate }: { onNavigate?: () => void }) {
  const [location] = useLocation();
  
  const links = [
    { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
    { href: "/accounts", label: "Customer Accounts", icon: Users },
    { href: "/transactions", label: "Transactions", icon: ArrowRightLeft },
  ];

  return (
    <div className="flex flex-col gap-1">
      {links.map((link) => {
        const active = location.startsWith(link.href);
        const Icon = link.icon;
        return (
          <Link
            key={link.href}
            href={link.href}
            onClick={onNavigate}
            className={`flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-all ${
              active
                ? "bg-primary text-primary-foreground"
                : "text-muted-foreground hover:bg-muted hover:text-foreground"
            }`}
          >
            <Icon className="h-4 w-4" />
            {link.label}
          </Link>
        );
      })}
    </div>
  );
}

export function Layout({ children }: { children: React.ReactNode }) {
  const [open, setOpen] = useState(false);

  return (
    <div className="grid min-h-screen w-full md:grid-cols-[240px_1fr] lg:grid-cols-[280px_1fr]">
      <div className="hidden border-r bg-muted/30 md:flex md:flex-col">
        <div className="flex h-16 items-center border-b px-5 gap-3 bg-primary text-primary-foreground">
          <Building2 className="h-7 w-7 shrink-0" />
          <div>
            <div className="font-bold text-sm leading-tight">{BANK_NAME}</div>
            <div className="text-[10px] opacity-70 leading-tight">{BANK_TAGLINE}</div>
          </div>
        </div>
        <div className="flex-1 overflow-auto py-4">
          <div className="px-3 mb-2">
            <p className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wider px-1 mb-1">Navigation</p>
          </div>
          <nav className="px-2">
            <NavLinks />
          </nav>
        </div>
        <div className="border-t p-4">
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <ShieldCheck className="h-3.5 w-3.5 text-emerald-500" />
            <span>Secured Banking System</span>
          </div>
        </div>
      </div>

      <div className="flex flex-col">
        <header className="flex h-14 items-center gap-4 border-b bg-white px-4 lg:h-[60px] lg:px-6 shadow-sm">
          <Sheet open={open} onOpenChange={setOpen}>
            <SheetTrigger asChild>
              <Button variant="outline" size="icon" className="shrink-0 md:hidden">
                <Menu className="h-5 w-5" />
                <span className="sr-only">Toggle navigation menu</span>
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="flex flex-col p-0">
              <div className="flex h-16 items-center gap-3 bg-primary text-primary-foreground px-5">
                <Building2 className="h-7 w-7 shrink-0" />
                <div>
                  <div className="font-bold text-sm leading-tight">{BANK_NAME}</div>
                  <div className="text-[10px] opacity-70 leading-tight">{BANK_TAGLINE}</div>
                </div>
              </div>
              <nav className="flex-1 p-3" onClick={() => setOpen(false)}>
                <NavLinks onNavigate={() => setOpen(false)} />
              </nav>
              <div className="border-t p-4">
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <ShieldCheck className="h-3.5 w-3.5 text-emerald-500" />
                  <span>Secured Banking System</span>
                </div>
              </div>
            </SheetContent>
          </Sheet>
          <div className="flex-1">
            <div className="md:hidden flex items-center gap-2">
              <Building2 className="h-5 w-5 text-primary" />
              <span className="font-bold text-sm text-primary">{BANK_NAME}</span>
            </div>
          </div>
          <div className="flex items-center gap-2 text-xs font-medium text-muted-foreground border rounded-full px-3 py-1">
            <ShieldCheck className="h-3.5 w-3.5 text-emerald-500" />
            <span>Secure Session</span>
          </div>
        </header>
        <main className="flex flex-1 flex-col gap-4 p-4 lg:gap-6 lg:p-8 bg-slate-50 min-h-0">
          {children}
        </main>
      </div>
    </div>
  );
}
