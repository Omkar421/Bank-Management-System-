import { Router } from "express";
import { db } from "@workspace/db";
import { accountsTable } from "@workspace/db";
import { eq, ilike, or, sql } from "drizzle-orm";
import {
  CreateAccountBody,
  UpdateAccountBody,
  ListAccountsQueryParams,
  GetAccountParams,
  UpdateAccountParams,
  DeleteAccountParams,
} from "@workspace/api-zod";

const router = Router();

function generateAccountNumber(): string {
  const num = Math.floor(1000000000 + Math.random() * 9000000000);
  return `ACC${num}`;
}

router.get("/", async (req, res) => {
  const parsed = ListAccountsQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid query params" });
    return;
  }
  const { search } = parsed.data;
  let accounts;
  if (search) {
    accounts = await db.select().from(accountsTable).where(
      or(
        ilike(accountsTable.holderName, `%${search}%`),
        ilike(accountsTable.accountNumber, `%${search}%`),
        ilike(accountsTable.email, `%${search}%`),
      )
    );
  } else {
    accounts = await db.select().from(accountsTable).orderBy(sql`${accountsTable.createdAt} desc`);
  }
  const mapped = accounts.map(a => ({
    ...a,
    balance: parseFloat(a.balance),
    createdAt: a.createdAt.toISOString(),
  }));
  res.json(mapped);
});

router.post("/", async (req, res) => {
  const parsed = CreateAccountBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid request body" });
    return;
  }
  const { holderName, email, phone, address, accountType, initialDeposit } = parsed.data;
  const accountNumber = generateAccountNumber();
  const [account] = await db.insert(accountsTable).values({
    accountNumber,
    holderName,
    email,
    phone,
    address: address ?? "",
    accountType,
    balance: initialDeposit.toFixed(2),
    status: "active",
  }).returning();
  res.status(201).json({
    ...account,
    balance: parseFloat(account.balance),
    createdAt: account.createdAt.toISOString(),
  });
});

router.get("/:id", async (req, res) => {
  const parsed = GetAccountParams.safeParse({ id: Number(req.params.id) });
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid id" });
    return;
  }
  const [account] = await db.select().from(accountsTable).where(eq(accountsTable.id, parsed.data.id));
  if (!account) {
    res.status(404).json({ error: "Account not found" });
    return;
  }
  res.json({
    ...account,
    balance: parseFloat(account.balance),
    createdAt: account.createdAt.toISOString(),
  });
});

router.put("/:id", async (req, res) => {
  const parsedParams = UpdateAccountParams.safeParse({ id: Number(req.params.id) });
  const parsedBody = UpdateAccountBody.safeParse(req.body);
  if (!parsedParams.success || !parsedBody.success) {
    res.status(400).json({ error: "Invalid request" });
    return;
  }
  const updates: Record<string, unknown> = {};
  const { holderName, email, phone, address, status } = parsedBody.data;
  if (holderName !== undefined) updates.holderName = holderName;
  if (email !== undefined) updates.email = email;
  if (phone !== undefined) updates.phone = phone;
  if (address !== undefined) updates.address = address;
  if (status !== undefined) updates.status = status;

  const [account] = await db.update(accountsTable).set(updates).where(eq(accountsTable.id, parsedParams.data.id)).returning();
  if (!account) {
    res.status(404).json({ error: "Account not found" });
    return;
  }
  res.json({
    ...account,
    balance: parseFloat(account.balance),
    createdAt: account.createdAt.toISOString(),
  });
});

router.delete("/:id", async (req, res) => {
  const parsed = DeleteAccountParams.safeParse({ id: Number(req.params.id) });
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid id" });
    return;
  }
  await db.delete(accountsTable).where(eq(accountsTable.id, parsed.data.id));
  res.status(204).send();
});

export default router;
