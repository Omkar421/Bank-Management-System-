import { Router } from "express";
import { db } from "@workspace/db";
import { accountsTable, transactionsTable } from "@workspace/db";
import { eq, sql, sum, count } from "drizzle-orm";

const router = Router();

router.get("/summary", async (_req, res) => {
  const [totals] = await db.select({
    totalAccounts: count(),
    totalBalance: sum(accountsTable.balance),
  }).from(accountsTable);

  const [activeCount] = await db.select({
    activeAccounts: count(),
  }).from(accountsTable).where(eq(accountsTable.status, "active"));

  const [deposits] = await db.select({
    totalDeposits: sum(transactionsTable.amount),
  }).from(transactionsTable).where(eq(transactionsTable.type, "deposit"));

  const [withdrawals] = await db.select({
    totalWithdrawals: sum(transactionsTable.amount),
  }).from(transactionsTable).where(eq(transactionsTable.type, "withdrawal"));

  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const [todayTxns] = await db.select({
    transactionsToday: count(),
  }).from(transactionsTable).where(sql`${transactionsTable.createdAt} >= ${today}`);

  res.json({
    totalAccounts: Number(totals.totalAccounts ?? 0),
    activeAccounts: Number(activeCount.activeAccounts ?? 0),
    totalDeposits: parseFloat(deposits.totalDeposits ?? "0"),
    totalWithdrawals: parseFloat(withdrawals.totalWithdrawals ?? "0"),
    totalBalance: parseFloat(totals.totalBalance ?? "0"),
    transactionsToday: Number(todayTxns.transactionsToday ?? 0),
  });
});

router.get("/recent-transactions", async (_req, res) => {
  const txns = await db
    .select({
      id: transactionsTable.id,
      accountId: transactionsTable.accountId,
      accountNumber: accountsTable.accountNumber,
      holderName: accountsTable.holderName,
      type: transactionsTable.type,
      amount: transactionsTable.amount,
      balanceAfter: transactionsTable.balanceAfter,
      description: transactionsTable.description,
      toAccountId: transactionsTable.toAccountId,
      createdAt: transactionsTable.createdAt,
    })
    .from(transactionsTable)
    .innerJoin(accountsTable, eq(transactionsTable.accountId, accountsTable.id))
    .orderBy(sql`${transactionsTable.createdAt} desc`)
    .limit(10);

  res.json(txns.map(t => ({
    ...t,
    amount: parseFloat(t.amount),
    balanceAfter: parseFloat(t.balanceAfter),
    createdAt: t.createdAt.toISOString(),
  })));
});

export default router;
