import { Router } from "express";
import { db } from "@workspace/db";
import { accountsTable, transactionsTable } from "@workspace/db";
import { eq, sql } from "drizzle-orm";
import {
  CreateTransactionBody,
  ListTransactionsQueryParams,
} from "@workspace/api-zod";

const router = Router();

router.get("/", async (req, res) => {
  const parsed = ListTransactionsQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid query params" });
    return;
  }
  const { accountId, type } = parsed.data;

  let query = db
    .select({
      id: transactionsTable.id,
      accountId: transactionsTable.accountId,
      accountNumber: accountsTable.accountNumber,
      holderName: accountsTable.holderName,
      type: transactionsTable.type,
      amount: transactionsTable.amount,
      balanceAfter: transactionsTable.balanceAfter,
      description: transactionsTable.description,
      toAccountId: transactionsTable.toAccountId,
      createdAt: transactionsTable.createdAt,
    })
    .from(transactionsTable)
    .innerJoin(accountsTable, eq(transactionsTable.accountId, accountsTable.id))
    .orderBy(sql`${transactionsTable.createdAt} desc`)
    .$dynamic();

  if (accountId) {
    query = query.where(eq(transactionsTable.accountId, accountId)) as typeof query;
  }

  const txns = await query;
  const filtered = type
    ? txns.filter(t => t.type === type)
    : txns;

  res.json(filtered.map(t => ({
    ...t,
    amount: parseFloat(t.amount),
    balanceAfter: parseFloat(t.balanceAfter),
    createdAt: t.createdAt.toISOString(),
  })));
});

router.post("/", async (req, res) => {
  const parsed = CreateTransactionBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid request body" });
    return;
  }
  const { accountId, type, amount, description, toAccountId } = parsed.data;

  const [account] = await db.select().from(accountsTable).where(eq(accountsTable.id, accountId));
  if (!account) {
    res.status(404).json({ error: "Account not found" });
    return;
  }

  const currentBalance = parseFloat(account.balance);

  if (type === "withdrawal" || type === "transfer") {
    if (currentBalance < amount) {
      res.status(400).json({ error: "Insufficient funds" });
      return;
    }
  }

  let newBalance = currentBalance;
  if (type === "deposit") {
    newBalance = currentBalance + amount;
  } else if (type === "withdrawal") {
    newBalance = currentBalance - amount;
  } else if (type === "transfer") {
    if (!toAccountId) {
      res.status(400).json({ error: "toAccountId is required for transfers" });
      return;
    }
    const [toAccount] = await db.select().from(accountsTable).where(eq(accountsTable.id, toAccountId));
    if (!toAccount) {
      res.status(404).json({ error: "Destination account not found" });
      return;
    }
    newBalance = currentBalance - amount;
    const toBalance = parseFloat(toAccount.balance) + amount;
    await db.update(accountsTable).set({ balance: toBalance.toFixed(2) }).where(eq(accountsTable.id, toAccountId));
    await db.insert(transactionsTable).values({
      accountId: toAccountId,
      type: "deposit",
      amount: amount.toFixed(2),
      balanceAfter: toBalance.toFixed(2),
      description: `Transfer received from ${account.holderName} (${account.accountNumber})`,
      toAccountId: null,
    });
  }

  await db.update(accountsTable).set({ balance: newBalance.toFixed(2) }).where(eq(accountsTable.id, accountId));

  const [txn] = await db.insert(transactionsTable).values({
    accountId,
    type,
    amount: amount.toFixed(2),
    balanceAfter: newBalance.toFixed(2),
    description,
    toAccountId: toAccountId ?? null,
  }).returning();

  res.status(201).json({
    ...txn,
    accountNumber: account.accountNumber,
    holderName: account.holderName,
    amount: parseFloat(txn.amount),
    balanceAfter: parseFloat(txn.balanceAfter),
    createdAt: txn.createdAt.toISOString(),
  });
});

export default router;
